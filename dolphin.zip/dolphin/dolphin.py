import os
import time
import random
import string
import requests
import subprocess
import webbrowser

from colorama import Fore, Style
from pystyle import Write, Colors, Colorate, Box

def dolphin_boot():
    os.system("cls")
    logo = r"""
 ______   _______  ___      _______  __   __  ___   __    _  _______  _______  _______  _______ 
|      | |       ||   |    |       ||  | |  ||   | |  |  | ||  _    ||       ||       ||       |
|  _    ||   _   ||   |    |    _  ||  |_|  ||   | |   |_| || |_|   ||   _   ||   _   ||_     _|
| | |   ||  | |  ||   |    |   |_| ||       ||   | |       ||       ||  | |  ||  | |  |  |   |  
| |_|   ||  |_|  ||   |___ |    ___||       ||   | |  _    ||  _   | |  |_|  ||  |_|  |  |   |  
|       ||       ||       ||   |    |   _   ||   | | | |   || |_|   ||       ||       |  |   |  
|______| |_______||_______||___|    |__| |__||___| |_|  |__||_______||_______||_______|  |___|  
"""
    print(Colorate.Horizontal(Colors.blue_to_white, logo))
    time.sleep(1)
    messages = [
        "[+] Initializing Dolphin OS kernel...",
        "[+] Loading system drivers...",
        "[+] Mounting virtual file system...",
        "[+] Starting GUI modules...",
        "[+] Checking network connectivity...",
        "[+] Finalizing boot sequence..."
    ]
    for i, msg in enumerate(messages, 1):
        bar = "█" * i + "-" * (len(messages) - i)
        print(Fore.CYAN + f"[{bar}] {msg}" + Fore.WHITE)
        time.sleep(0.2)
    print(Fore.GREEN + "\n[✔] Dolphin OS boot complete!" + Fore.WHITE)
    time.sleep(1)
    os.system("cls")

def loading_bar(duration=1):
    steps = 30
    for i in range(steps):
        bar = "█" * (i+1) + "-" * (steps-i-1)
        print(Fore.CYAN + f"[{bar}] {int((i+1)/steps*100)}%" + Fore.WHITE, end="\r")
        time.sleep(duration/steps)
    print("\n")

def show_menu():
    os.system("cls")
    print(Colorate.Horizontal(Colors.blue_to_white, r'''
                                                                                            YAao,                             +-----------------------------+
                                                                                             Y8888b,                          |        ,                  ^ |
                                                                                           ,oA8888888b,                       |      __)\_    dolphin OS  | |
                                                                                     ,aaad8888888888888888bo,                 |(\_.-'    a`-. : USERNAMES | |
                                                                                  ,d888888888888888888888888888b,             |(/~~````(/~^^` : PASSWORDS | |
                                                                                ,888888888888888888888888888888888b,          |                           | |
                                                                               d8888888888888888888888888888888888888,        | | 1 | Username generator  | |
                                                                              d888888888888888888888888888888888888888b       | | 2 | Password generator  | |
                                                                             d888888P'                    `Y888888888888,     | | 3 | SQL inject          | |
                                                                             88888P'                    Ybaaaa8888888888l     | | 4 | discord             | |
                                                                            a8888'      _     _     _   `Y8888P' `V888888     | | 5 | install blackarch   | |
                                                                          d8888888a   _| |___| |___| |_|_|___      `Y8888     | | 6 | install kali linux  | |
                                                                         AY/'' `\Y8b | . | . | | . |   | |   |       ``Y8b    | | 7 | install vbox        | |
                                                                         Y'      `YP |___|___|_|  _|_|_|_|_|_|          ~~    |<--------------------------+ |
'''))
    return input(Fore.CYAN + "[+] Enter choice: " + Fore.WHITE)

def username_generator():
    os.system("cls")
    print(Colorate.Horizontal(Colors.blue_to_white, """
                                                                                            YAao,                             
                                                                                             Y8888b,                          
                                                                                           ,oA8888888b,                       
                                                                                     ,aaad8888888888888888bo,                 
                                                                                  ,d888888888888888888888888888b,             
                                                                                ,888888888888888888888888888888888b,          
                                                                               d8888888888888888888888888888888888888,        
                                                                              d888888888888888888888888888888888888888b       
                                                                             d888888P'                    `Y888888888888,     
                                                                             88888P'                    Ybaaaa8888888888l     
                                                                            a8888'      _     _     _   `Y8888P' `V888888     
                                                                          d8888888a   _| |___| |___| |_|_|___      `Y8888     
                                                                         AY/'' `\Y8b | . | . | | . |   | |   |       ``Y8b    
                                                                         Y'      `YP |___|___|_|  _|_|_|_|_|_|          ~~    [ - ] Username Generator
"""))
    amount = input(Fore.CYAN + "[+] amount: " + Fore.WHITE)
    try:
        amount = int(amount)
    except:
        print(Fore.RED + "[!] Invalid number." + Fore.WHITE)
        time.sleep(1)
        return

    os.system("cls")
    print(Fore.CYAN + f"[+] Generating {amount} usernames..." + Fore.WHITE)
    loading_bar(0.8)

    def make_user():
        return ''.join(random.choices(string.ascii_letters + string.digits, k=4))

    valid = 0
    invalid = 0

    for _ in range(amount):
        u = make_user()
        url = f"https://www.tiktok.com/@{u}"

        try:
            r = requests.head(url, timeout=1)
            if r.status_code == 404:
                print(Fore.GREEN + "[VALID]    " + Fore.WHITE + "| " + u)
                valid += 1
            else:
                print(Fore.BLUE + "[INVALID]  " + Fore.WHITE + "| " + u)
                invalid += 1
        except:
            print(Fore.BLUE + "[INVALID]  " + Fore.WHITE + "| " + u)
            invalid += 1

    print(Fore.CYAN + "\n-----------------------------------" + Fore.WHITE)
    print("valid names: " + str(valid))
    print("invalid names: " + str(invalid))
    print(Fore.CYAN + "-----------------------------------" + Fore.WHITE)
    input(Fore.MAGENTA + "\n[+] Press ENTER to return..." + Fore.WHITE)

def password_generator():
    os.system("cls")
    print(Colorate.Horizontal(Colors.blue_to_white, """
                                                                                            YAao,                             
                                                                                             Y8888b,                          
                                                                                           ,oA8888888b,                       
                                                                                     ,aaad8888888888888888bo,                 
                                                                                  ,d888888888888888888888888888b,             
                                                                                ,888888888888888888888888888888888b,          
                                                                               d8888888888888888888888888888888888888,        
                                                                              d888888888888888888888888888888888888888b       
                                                                             d888888P'                    `Y888888888888,     
                                                                             88888P'                    Ybaaaa8888888888l     
                                                                            a8888'      _     _     _   `Y8888P' `V888888     
                                                                          d8888888a   _| |___| |___| |_|_|___      `Y8888     
                                                                         AY/'' `\Y8b | . | . | | . |   | |   |       ``Y8b    
                                                                         Y'      `YP |___|___|_|  _|_|_|_|_|_|          ~~    [ - ] Password Generator
"""))
    amount = input(Fore.CYAN + "[+] amount: " + Fore.WHITE)
    try:
        amount = int(amount)
    except:
        print(Fore.RED + "[!] Invalid number." + Fore.WHITE)
        time.sleep(1)
        return

    chars = string.ascii_letters + string.digits + string.punctuation

    os.system("cls")
    print(Fore.CYAN + f"[+] Generating {amount} passwords..." + Fore.WHITE)
    loading_bar(0.8)

    for _ in range(amount):
        print(''.join(random.choices(chars, k=90)))

    print(Fore.CYAN + "\n-----------------------------------")
    print("generated passwords: " + str(amount))
    print("-----------------------------------" + Fore.WHITE)
    input(Fore.MAGENTA + "\n[+] Press ENTER to return..." + Fore.WHITE)

def sql_inject():
    os.system("cls")
    print(Colorate.Horizontal(Colors.blue_to_white, """
                                                                                            YAao,                             
                                                                                             Y8888b,                          
                                                                                           ,oA8888888b,                       
                                                                                     ,aaad8888888888888888bo,                 
                                                                                  ,d888888888888888888888888888b,             
                                                                                ,888888888888888888888888888888888b,          
                                                                               d8888888888888888888888888888888888888,        
                                                                              d888888888888888888888888888888888888888b       
                                                                             d888888P'                    `Y888888888888,     
                                                                             88888P'                    Ybaaaa8888888888l     
                                                                            a8888'      _     _     _   `Y8888P' `V888888     
                                                                          d8888888a   _| |___| |___| |_|_|___      `Y8888     
                                                                         AY/'' `\Y8b | . | . | | . |   | |   |       ``Y8b    
                                                                         Y'      `YP |___|___|_|  _|_|_|_|_|_|          ~~    [ - ] SQLMAP Launcher
"""))
    path = os.path.join(os.getcwd(), "sql", "sqlmap.py")
    if os.path.exists(path):
        print(Fore.GREEN + "[+] Launching sqlmap..." + Fore.WHITE)
        time.sleep(1)
        os.system("cls")
        subprocess.Popen(["python", path])
        input(Fore.YELLOW + "[+] Press anything to go back..." + Fore.WHITE)
    else:
        print(Fore.RED + "[!] sqlmap.py not found in /sql" + Fore.WHITE)
        input(Fore.MAGENTA + "[+] Press ENTER to return..." + Fore.WHITE)

def discord():
    os.system("cls")
    print(Fore.CYAN + "[+] Opening Discord invite..." + Fore.WHITE)
    webbrowser.open("https://discord.gg/vUY2MRx6ke")
    input(Fore.MAGENTA + "[+] Press ENTER to return..." + Fore.WHITE)

def blackarch():
    os.system("cls")
    print(Fore.CYAN + "[+] Opening BlackArch..." + Fore.WHITE)
    webbrowser.open("https://blackarch.org")
    input(Fore.MAGENTA + "[+] Press ENTER to return..." + Fore.WHITE)

def kali():
    os.system("cls")
    print(Fore.CYAN + "[+] Opening Kali Linux..." + Fore.WHITE)
    webbrowser.open("https://www.kali.org")
    input(Fore.MAGENTA + "[+] Press ENTER to return..." + Fore.WHITE)

def vbox():
    os.system("cls")
    print(Fore.CYAN + "[+] Opening VirtualBox..." + Fore.WHITE)
    webbrowser.open("https://www.virtualbox.org")
    input(Fore.MAGENTA + "[+] Press ENTER to return..." + Fore.WHITE)

def main():
    os.system("title Dolphin OS")
    print("GO INTO FULL SCREEN (LOADING..10s)")
    time.sleep(3)
    dolphin_boot()
    while True:
        choice = show_menu()
        if choice == "1":
            username_generator()
        elif choice == "2":
            password_generator()
        elif choice == "3":
            sql_inject()
        elif choice == "4":
            discord()
        elif choice == "5":
            blackarch()
        elif choice == "6":
            kali()
        elif choice == "7":
            vbox()
        else:
            print(Fore.RED + "[!] Invalid option." + Fore.WHITE)
            time.sleep(1)

if __name__ == "__main__":
    main()
