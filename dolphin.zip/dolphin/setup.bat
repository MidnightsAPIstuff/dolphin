@echo off
title Dolphin OS + SQLMap Dependency Installer
echo ----------------------------------------------
echo       setup hhhhhhhhhhhhhhhhhhhhhhho
echo ----------------------------------------------
echo.

REM --- Check if Python exists ---
python --version >nul 2>&1
IF %ERRORLEVEL% NEQ 0 (
    echo [!] Python is not installed. Please install Python 3.
    pause
    exit /b
)

echo [+] Upgrading pip...
python -m pip install --upgrade pip

echo.
echo [+] Installing Dolphin OS Python dependencies...
python -m pip install colorama pystyle requests

echo.
echo [+] Installing SQLMap dependencies...
python -m pip install chardet urllib3 idna certifi

echo.
echo [✔] done
echo.
pause
